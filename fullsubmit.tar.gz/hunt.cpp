
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <cmath>
#include <iostream>
#include <algorithm>

using namespace std; 

class Map {

};

int main()
{

}